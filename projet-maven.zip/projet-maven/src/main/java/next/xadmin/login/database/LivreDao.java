package next.xadmin.login.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import next.xadmin.login.bean.LivreBean;

public class LivreDao {
	public List<LivreBean> recupererlivres(){
			List<LivreBean> livres = new ArrayList<LivreBean>();
			
			//chargement du driver 
			try {
			Class.forName("");
			} catch(ClassNotFoundException e){
				
			}
			
			//connexion a la base
			Connection connexion = null;
		    Statement statement = null;
		    ResultSet resultat = null;
		    try {
		    	connexion = DriverManager.getConnection("");
		    	statement = connexion.createStatement();
		    	//execution de la requete 
		    	while (resultat.next()) {
		    		String domaine = resultat.getString("type");
		    		String titre = resultat.getString("titre");	
		    		
		    		LivreBean livre = new LivreBean();
		    		
					livre.setType(type);
		    		livre.setTitre(titre);
		    		livre.setAuteur(auteur);
		    		
		    		livres.add(livre);
		    	}
		    } catch(SQLException ignore) {
		    	
		    
		}
			return livres;
		}
}

