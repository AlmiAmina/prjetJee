package next.xadmin.login.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import next.xadmin.login.bean.LoginBean;

public class LoginDao {
	private String dbUrl ="jdbc:mysql://localhost:3306/mina";
	private String dbUname ="root";
	private String dbPassword ="mama101064";
	private String dbDriver ="com.mysql.jdbc.Driver";
	public void loadDriver(String dbDriver) {
		try {Class.forName(dbDriver); }
			 catch (ClassNotFoundException e) {
			e.printStackTrace();}
		//Resultset resultat = null;
		
		//connection a la base;
	}

	public Connection getConnection() {
		// TODO Auto-generated method stub
		Connection con = null;
			try {
				con= DriverManager.getConnection(dbUrl, dbUname, dbPassword);
				//statement = connection.createStatement();
			} catch(SQLException e) { 
				e.printStackTrace();
				}
			return con;
		}
		//pour valider le mat l'eami et le mot de passe
		
	

	public boolean validate (LoginBean loginBean) {
		// TODO Auto-generated method stub
		loadDriver(dbDriver);
		Connection con=getConnection();
		boolean status = false;
		String sql = "select * from Login where email=? and password=?";
		PreparedStatement ps;
		
		try {
		ps = con.prepareStatement(sql);
		
		ps.setString(1, loginBean.getEmail());
		ps.setString(1, loginBean.getPassword());
		
		ResultSet rs = ps.executeQuery();
		status= rs.next();
		}
		catch(SQLException e) { 
			e.printStackTrace();
			}
		
		return status;
	}
	
}
