package next.xadmin.login.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import next.xadmin.login.bean.LoginBean;
import next.xadmin.login.database.LoginDao;
/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/login")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//private Object;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet(){
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		
		
	    LoginBean LoginBean = new LoginBean();
		LoginBean.setEmail(email);
		LoginBean.setPassword(password);
		
		LoginDao LoginDao = new LoginDao();
		
		
		doGet(request, response);
		if (LoginDao.validate(LoginBean)) 
			{
			response.sendRedirect("http://localhost:8080/jee/connectReussi.jsp");
		}
			else {
				response.sendRedirect("http://localhost:8080/jee/login.jsp");	
			}
	}

}
