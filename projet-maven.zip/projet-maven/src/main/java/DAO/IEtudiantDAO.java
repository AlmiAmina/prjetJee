package DAO;

public interface IEtudiantDAO {

}
