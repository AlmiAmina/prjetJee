package DAO;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entities.Etudiants;

public class EtudiantDAO implements IEtudiantDAO {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BibNumerique"); 
	 
	EntityManager entityManager = entityManagerFactory.createEntityManager(); 
	EntityTransaction transaction = entityManager.getTransaction();
	public void add(Etudiants e)   {   
		transaction.begin();      
		entityManager.persist(e);         
		transaction.commit();           
	}

}
