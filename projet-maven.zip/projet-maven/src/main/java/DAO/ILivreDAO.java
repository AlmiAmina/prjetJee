package DAO;

public interface ILivreDAO {

}
