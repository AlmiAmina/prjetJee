package DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entities.Livres;

public class LivreDAO implements ILivreDAO {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BibNumerique"); 
	 
	EntityManager entityManager = entityManagerFactory.createEntityManager(); 
	EntityTransaction transaction = entityManager.getTransaction();
	public void add(Livres l)   {   
		transaction.begin();      
		entityManager.persist(l);         
		transaction.commit();           
	}
	
	@SuppressWarnings("unchecked")
	/*public List <Livres> Lister(String Livres){
		List <Livres> livre=entityManager.createQuery("select  from "+Livres+"").getResultList();
}*/
	public Livres retournerLivre(String type) {
		Query req=this.entityManager.createQuery("select l frome Livres l where type="+type, Livres.class);
List <Livres> Livreliste = req.getResultList();
return Livreliste.get(0);
	}
	
	
	
}
