package entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="Livres")
//@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
public class Livres {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
		public String type;
		public String titre;
		public String auteur;
		
		public Livres() { this("unknown", "unknown", "unknown");}

		public Livres(String type, String titre, String auteur) {
			// TODO Auto-generated constructor stub
			this.SetType(type);
			this.SetTitre(titre);
			this.SetAuteur(auteur);
		}

		private void SetTitre(String titre) {
			// TODO Auto-generated method stub
			this.titre =titre;
		}

		private void SetAuteur(String auteur) {
			// TODO Auto-generated method stub
			this.auteur = auteur;
		}

		private void SetType(String type) {
			// TODO Auto-generated method stub
			this.type = type;
		}

		public String getType() {
			return type;
		}

		public String getTitre() {
			return titre;
		}

		public String getAuteur() {
			return auteur;
		}

		@Override
		public String toString() {
			return "Livres [type=" + type + ", titre=" + titre + ", auteur=" + auteur + "]";
		}

		
}
