package entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="Etudiants")

public class Etudiants {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	public String email;
	public String password;
	
	public Etudiants() { this("unknown", "unknown");}

	public Etudiants(String email, String password) {
		// TODO Auto-generated constructor stub
		this.SetEmail(email);
		this.SetPassword(password);
	}
	public String getEmail() {
		return email;
	}
	private void SetEmail(String email) {
		// TODO Auto-generated method stub
		this.email = email;	
	}
	public String getPassword() {
		return password;
	}
	private void SetPassword(String password) {
		// TODO Auto-generated method stub
		this.password = password;	
	}

}
